<?php
/**
 * AIFO Fail Handler for WHMCS
 * Обробник невдалого платежу AIFO для WHMCS
 * 
 * @package    AIFO
 * @author     AIFO.PRO
 * @copyright  Copyright (c) 2026 AIFO.PRO
 * @license    Proprietary
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

// Redirect to invoice page
header("Location: " . $CONFIG['SystemURL'] . "/viewinvoice.php?id=" . $_GET['invoice']);
exit;

