<?php
/**
 * AIFO Payment Gateway for WHMCS
 * Платіжний шлюз AIFO для WHMCS
 * 
 * @package    AIFO
 * @author     AIFO.PRO
 * @copyright  Copyright (c) 2026 AIFO.PRO
 * @license    Proprietary
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function aifo_config() {
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'AIFO'
        ),
        'shop_id' => array(
            'FriendlyName' => 'ID Магазину',
            'Type' => 'text',
            'Size' => '50',
            'Description' => 'ID магазину з особистого кабінету AIFO'
        ),
        'secret_key' => array(
            'FriendlyName' => 'Секретний ключ',
            'Type' => 'password',
            'Size' => '50',
            'Description' => 'Секретний ключ з особистого кабінету AIFO'
        ),
        'signature_type' => array(
            'FriendlyName' => 'Тип підпису',
            'Type' => 'dropdown',
            'Options' => array(
                '1' => 'MD5',
                '2' => 'SHA256',
                '3' => 'SHA1',
                '4' => 'RIPEMD160',
                '5' => 'SHA384',
                '6' => 'SHA512'
            ),
            'Default' => '1',
            'Description' => 'Тип хешування для підпису'
        ),
        'aifo_url' => array(
            'FriendlyName' => 'URL сервісу AIFO',
            'Type' => 'text',
            'Size' => '50',
            'Default' => 'https://aifo.pro',
            'Description' => 'URL сервісу AIFO (за замовчуванням: https://aifo.pro)'
        )
    );
}

function aifo_link($params) {
    $shop_id = $params['shop_id'];
    $secret_key = $params['secret_key'];
    $signature_type = isset($params['signature_type']) ? (int)$params['signature_type'] : 1;
    $aifo_url = isset($params['aifo_url']) ? trim($params['aifo_url']) : 'https://aifo.pro';
    
    $amount = $params['amount'];
    $invoiceid = $params['invoiceid'];
    $description = $params['description'];
    
    // Генерация подписи в зависимости от типа
    $sign = '';
    if ($signature_type == 1) {
        $sign = md5($shop_id . ':' . $amount . ':' . $secret_key . ':' . $invoiceid);
    } elseif ($signature_type == 2) {
        $sign = hash('sha256', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $invoiceid);
    } elseif ($signature_type == 3) {
        $sign = hash('sha1', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $invoiceid);
    } elseif ($signature_type == 4) {
        $sign = hash('ripemd160', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $invoiceid);
    } elseif ($signature_type == 5) {
        $sign = hash('sha384', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $invoiceid);
    } elseif ($signature_type == 6) {
        $sign = hash('sha512', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $invoiceid);
    } else {
        $sign = md5($shop_id . ':' . $amount . ':' . $secret_key . ':' . $invoiceid);
    }
    
    $payment_url = rtrim($aifo_url, '/') . '/pay/';
    
    $code = '<form method="get" action="' . htmlspecialchars($payment_url) . '">';
    $code .= '<input type="hidden" name="shop_id" value="' . htmlspecialchars($shop_id) . '" />';
    $code .= '<input type="hidden" name="amount" value="' . htmlspecialchars($amount) . '" />';
    $code .= '<input type="hidden" name="id" value="' . htmlspecialchars($invoiceid) . '" />';
    $code .= '<input type="hidden" name="desc" value="' . htmlspecialchars($description) . '" />';
    $code .= '<input type="hidden" name="sign" value="' . htmlspecialchars($sign) . '" />';
    $code .= '<input type="submit" value="Оплатити через AIFO" />';
    $code .= '</form>';
    
    return $code;
}

