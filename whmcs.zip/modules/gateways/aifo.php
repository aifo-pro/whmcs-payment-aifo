<?php
/**
 * AIFO Payment Gateway Callback Handler for WHMCS
 * Обробник зворотного виклику платіжного шлюзу AIFO для WHMCS
 * 
 * @package    AIFO
 * @author     AIFO.PRO
 * @copyright  Copyright (c) 2026 AIFO.PRO
 * @license    Proprietary
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

include('../../../includes/gatewayfunctions.php');
include('../../../includes/invoicefunctions.php');

$gatewaymodule = 'aifo';
$GATEWAY = getGatewayVariables($gatewaymodule);

if (isset($_REQUEST['invoice']) && isset($_REQUEST['http_auth_signature'])) {
	
	$shop_id = $GATEWAY['shop_id'];
	$secret_key = $GATEWAY['secret_key'];
	$signature_type = isset($GATEWAY['signature_type']) ? (int)$GATEWAY['signature_type'] : 1;
	
	// Генерация подписи в зависимости от типа
	$signature = '';
	if ($signature_type == 1) {
		$signature = md5($shop_id.":".$_REQUEST['sum'].":".$secret_key.":".$_REQUEST['invoice']);
	} elseif ($signature_type == 2) {
		$signature = hash('sha256', $shop_id.":".$_REQUEST['sum'].":".$secret_key.":".$_REQUEST['invoice']);
	} elseif ($signature_type == 3) {
		$signature = hash('sha1', $shop_id.":".$_REQUEST['sum'].":".$secret_key.":".$_REQUEST['invoice']);
	} elseif ($signature_type == 4) {
		$signature = hash('ripemd160', $shop_id.":".$_REQUEST['sum'].":".$secret_key.":".$_REQUEST['invoice']);
	} elseif ($signature_type == 5) {
		$signature = hash('sha384', $shop_id.":".$_REQUEST['sum'].":".$secret_key.":".$_REQUEST['invoice']);
	} elseif ($signature_type == 6) {
		$signature = hash('sha512', $shop_id.":".$_REQUEST['sum'].":".$secret_key.":".$_REQUEST['invoice']);
	} else {
		$signature = md5($shop_id.":".$_REQUEST['sum'].":".$secret_key.":".$_REQUEST['invoice']);
	}
	
    $log_text = "--------------------------------------------------------\n";
    foreach ($_REQUEST as $name => $value) {
        $log_text .= "{$name}: {$value}\n";
    }
    if (!empty($GATEWAY['aifo_logfile'])) {
        file_put_contents($_SERVER['DOCUMENT_ROOT'] . $GATEWAY['aifo_logfile'], $log_text, FILE_APPEND);
    }

    if ((string)$_REQUEST["http_auth_signature"] !== (string)$signature) {
        if (!empty($GATEWAY['aifo_email_error'])) {
            $to = $GATEWAY['aifo_email_error'];
            $subject = "Помилка оплати";
            $message = "Не вдалося провести платіж через систему AIFO з наступних причин:\n\n";
            $message .= " - Не співпадають цифрові підписи\n";
            $message .= "\n" . $log_text;
            $headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\nContent-type: text/plain; charset=utf-8 \r\n";
            mail($to, $subject, $message, $headers);
        }
        exit ($_REQUEST['invoice'] . ' | error signature');
    }

    // проверка принадлежности ip списку доверенных ip (если настроен)
    $valid_ip = true;
    if (!empty($GATEWAY['aifo_ipfilter'])) {
        $valid_ip = false;
        $sIP = str_replace(' ', '', $GATEWAY['aifo_ipfilter']);
        $array_IP = explode(',', $sIP);
        if (isset($_SERVER["HTTP_X_REAL_IP"])) {
            $cur_ip = $_SERVER["HTTP_X_REAL_IP"];
        } else {
            $cur_ip = $_SERVER["REMOTE_ADDR"];
        }
        if (in_array($cur_ip, $array_IP)) {
            $valid_ip = true;
        }
    }

    if ((string)$_REQUEST['http_auth_signature'] === (string)$signature && $valid_ip) {
        addInvoicePayment($_REQUEST['invoice'], $_REQUEST['MERCHANT_ID'], $payed, '', $gatewaymodule);
        logTransaction($GATEWAY['name'], $_REQUEST, 'Successful');
        exit ('YES');
    } else {
        if (!empty($GATEWAY['aifo_email_error'])) {
            $to = $GATEWAY['aifo_email_error'];
            $subject = "Помилка оплати";
            $message = "Не вдалося провести платіж через систему AIFO з наступних причин:\n\n";

            if (!$valid_ip) {
                $message .= " - IP-адреса сервера не є довіреною\n";
                $message .= '   довірених IP: ' . $sIP . "\n";
                $message .= '   IP поточного сервера: ' . $cur_ip . "\n";
            }

            $message .= "\n" . $log_text;
            $headers = 'From: no-reply@' . $_SERVER['HTTP_HOST'] . "\r\nContent-type: text/plain; charset=utf-8 \r\n";
            mail($to, $subject, $message, $headers);
        }

        logTransaction($GATEWAY['name'], $event, 'Unsuccessful');
        exit ($_REQUEST['invoice'] . ' | error | ' . (!$valid_ip ? 'ip' : 'signature'));
    }
} else {
    exit ($_REQUEST['invoice'] . ' | error | no parameters');
}

